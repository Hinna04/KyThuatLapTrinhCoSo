package bai11;
import java.util.Scanner;
public class Person {
	
	    private String hoTen;
	    private String diaChi;

	    public Person(){
	    	
	    }

	    public Person(String hoTen, String diaChi) {
	        this.hoTen = hoTen;
	        this.diaChi = diaChi;
	    }

	    public String getHoTen() {
	        return hoTen;
	    }

	    public void setHoTen(String hoTen) {
	        this.hoTen = hoTen;
	    }

	    public String getDiaChi() {
	        return diaChi;
	    }

	    public void setDiaChi(String diaChi) {
	        this.diaChi = diaChi;
	    }

	    public void hienThongTin(){
	        
	        System.out.println("Ho ten: " + this.hoTen);
	        System.out.println("Dia chi: " + this.diaChi);
	    }
	}


	