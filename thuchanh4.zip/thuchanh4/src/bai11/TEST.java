package bai11;
import java.util.*;
/**
 * 
 * Ho va ten: Phạm Thị Như Quỳnh
 *Lop: 2210A06
 */
public class TEST {
    public static void main(String[] args) {        
        DANHSACH dsbll = new DANHSACH();
        dsbll.nhapDanhSach();
        System.out.println("====Hien danh sach vua nhap====");
        dsbll.hienDanhSach();
        System.out.println("====Hien thong tin nguoi bi xoa====");
        dsbll.xoaNguoi();
        System.out.println("====Sap xep theo ho ten====");
        dsbll.sapXepTheoHoTen();
    }
}

