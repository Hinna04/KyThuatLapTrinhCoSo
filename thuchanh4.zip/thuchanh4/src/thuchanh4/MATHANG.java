package thuchanh4;
import java.util.Scanner;
public class MATHANG {
protected String tenHang;
protected String maHang;
protected String nuocSx;
	public MATHANG() {
		// TODO Auto-generated constructor stub
	}

	public MATHANG( String tenHang,String maHang, String nuocSx) {
		this.tenHang=tenHang;
		this.maHang=maHang;
		this.nuocSx=nuocSx;
	}
	public void nhap() {
		Scanner sc= new Scanner(System.in);
		System.out.println("Nhap ten hang:");
		this.tenHang=sc.nextLine();
		System.out.println("Nhap ma hang:");
		this.maHang= sc.nextLine();
		System.out.println("Nhap nuoc san xuat:");
		this.nuocSx=sc.nextLine();
	}
	public void xuat() {
			System.out.printf("\n%10s", tenHang);
			System.out.printf("%10s", maHang);
			System.out.printf("%10s", nuocSx);
			
	}
	public String getTenHang() {
		return tenHang;
	}
	public void setTenHang(String tenHang) {
		this.tenHang=tenHang;
}
	public String getMaHang() {
		return maHang;
	}
	public void setMaHang(String maHang) {
		this.maHang=maHang;
	}
	public String getNuocSx() {
		return nuocSx;
	}
	public void setNuocSx(String nuocSx) {
		this.nuocSx=nuocSx;
	}
	
}
