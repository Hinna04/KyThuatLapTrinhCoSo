package bai4;

import java.util.Scanner;

public class Chuvi_dientich {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

//		int cd, cr, cv, dt;
//		Scanner sc = new Scanner(System.in);
//		System.out.print("Nhap chieu dai: ");
//		cd = sc.nextInt();
//		System.out.print("Nhap chieu rong: ");
//		cr = sc.nextInt();
//		System.out.println("Chu vi hinh chu nhat: " + (cd+cr)*2);
//		System.out.println("Dien tich hinh chu nhat: " + cd*cr);
		int n;
		int a[];
		Scanner sc = new Scanner(System.in);
		System.out.print("Nhap so phan tu cua mang: ");
		n = sc.nextInt();
		a = new int [n];
		for(int i = 0; i < n; i++) {
			System.out.print("a[" + "]: ");
			a[i] = sc. nextInt();
		}
		System.out.print("\nMang da nhap: ");
		for(int i = 0; i < n; i++) 
			System.out.printf("%6d", a[i]);
		int s = 0; 
		for(int i = 0; i < n; i++) {
			s += a[i];
		}
		System.out.println("\nTong cac phan tu cua mang: " + s);
		

	}

}