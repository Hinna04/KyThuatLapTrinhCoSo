//package VD;
//
//import java.awt.GridLayout;
//import java.awt.event.ActionEvent;
//import java.awt.event.ActionListener;
//
//import javax.swing.JButton;
//import javax.swing.JFrame;
//import javax.swing.JLabel;
//import javax.swing.JPanel;
//import javax.swing.JTextField;
//import javax.swing.SpringLayout;
//
//public class USCLN extends JFrame implements ActionListener {
//	private static final String SpringLAyout = null;
//	JLabel lblA, lblB, lblResult;
//	JTextField txtA, txtB;
//	JButton btnTinh;
//	public USCLN() {
//		setTitle("Tim uoc so chung lon nhat");
//		lblA = new JLabel("So a: ");
//		lblB = new JLabel("So b: ");
//		lblResult = new JLabel("Ket qua: ");
//		txtA = new JTextField(10);
//		txtB = new JTextField(10);
//		txtResult.setEditable(false);
//		
//		btnTinh = new JButton("Tinh");
//		btnTinh.setActionCommand("btnTinh");
//		btnTinh.addActionListener(this);
//		
//				
//		SpringLayout sprLayout = new SpringLayout();
//		setLayout(sprLayout);
//		add (lblA);
//		add (txtA);
//		add (lblB);
//		sprLayout.putConstraint(SpringLayout.WEST, lblA, 10, SpringLayout.WEST, getContentPane());
//		sprLayout.putConstraint(SpringLAyout.WEST, txtA, 10, SpringLayout.EAST, lblA);
//		sprLayout.putConstraint(SpringLAyout.WEST, lblA, 10, SpringLAyout.WEST, getContentPane());
//		sprLayout.putConStraint(SpringLayout.SOUTH, lblB, 25, SpringLayout.SOUTH, lblA);
//		sprLayout.putConstraint(SpringLAyout.WEST, txtB, 25, SpringLAyout.EAST, lblB);
//		
//		pack();
//		setSize(300, 300);
//		setVisible(true);
//		
//	}
//	public void actionPerformed (ActionEvent e) {
//		if(e.getActionCommand() == "btnTinh") {
//			int a = Integer.parseInt(txtA.getText());
//			int b = Integer.parseInt(txtB.getText());
//			txtResult.setText(gdc(a, b) + "");
//		}
////		else if(e.getActionCommand())
//	}
//
//}
