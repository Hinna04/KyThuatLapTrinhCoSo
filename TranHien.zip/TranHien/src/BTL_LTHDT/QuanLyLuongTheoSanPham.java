package BTL_LTHDT;

public class QuanLyLuongTheoSanPham {

	public static void main(String[] args) {
		
	}

}
