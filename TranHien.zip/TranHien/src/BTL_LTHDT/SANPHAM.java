package BTL_LTHDT;

import java.util.Scanner;

public class SANPHAM {
	protected String maSP, tenSP;
	protected int NSX, HSD;
	Scanner sc = new Scanner(System.in);
	public void nhapsp() {
		System.out.print("Nhap ma san pham: ");
		maSP = sc.nextLine();
		System.out.print("Nhap ten san pham: ");
		tenSP = sc.nextLine();
		System.out.print("Nhap ngay san xuat: ");
		NSX = sc.nextInt();
		System.out.print("Nhap han su dung: ");
		HSD = sc.nextInt();
	}
	public void xuatsp() {
		System.out.println("Ma san pham: " + maSP);
		System.out.println("Ten san pham: " + tenSP);
		System.out.println("Ngay san xuat: " + NSX);
		System.out.println("Han su dung: " + HSD);
	}
	public String getMaSP() {
		return maSP;
	}
	public void setMaSP(String maSP) {
		this.maSP = maSP;
	}
	public String getTenSP() {
		return tenSP;
	}
	public void setTenSP(String tenSP) {
		this.tenSP = tenSP;
	}
	public int getNSX() {
		return NSX;
	}
	public void setNSX(int nSX) {
		NSX = nSX;
	}
	public int getHSD() {
		return HSD;
	}
	public void setHSD(int hSD) {
		HSD = hSD;
	}
	
}
