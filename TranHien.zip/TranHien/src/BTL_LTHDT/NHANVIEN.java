package BTL_LTHDT;

import java.util.Scanner;

public class NHANVIEN {
	protected String maNV, hoten, gioitinh;
	protected int ngaysinh;
	protected String sdt, email;
	protected float heSoLuong, luongCB;
	protected int soNgayDiLam;
	protected float soGioLamThem;
	protected String phongBan;
	Scanner sc = new Scanner(System.in);
	public NHANVIEN() {
		super();
	}
	public void nhap() {
		System.out.print("\nNhập mã nhân viên: ");
		maNV = sc.nextLine();
		System.out.print("Nhập họ và tên nhân viên: ");
		hoten = sc.nextLine();
		System.out.print("Nhập ngày sinh: ");
		ngaysinh = sc.nextInt();
		System.out.print("Nhập giới tính: ");
		gioitinh = sc.nextLine();
		System.out.print("Nhập ngày sinh: ");
		ngaysinh = sc.nextInt();
		System.out.print("Nhập số điện thoại: ");
		sdt = sc.nextLine();
		System.out.print("Nhập địa chỉ email: ");
		email = sc.nextLine();
		System.out.print("Nhập hệ số lương: ");
		heSoLuong = sc.nextFloat();
		System.out.print("Nhập số ngày đi làm: ");
	}
	public void xuat() {
		System.out.println("\nMã nhân viên: " + maNV);
		System.out.println("Họ và tên nhân viên: " + hoten);
		System.out.println("Ngày sinh : " + ngaysinh);
		System.out.println("Giới tính: " + gioitinh);
		System.out.println("Số điện thoại: " + sdt);
		System.out.println("Địa chỉ email: " + email);
	}
	public String getMaNV() {
		return maNV;
	}
	public void setMaNV(String maNV) {
		this.maNV = maNV;
	}
	public String getHoten() {
		return hoten;
	}
	public void setHoten(String hoten) {
		this.hoten = hoten;
	}
	public String getGioitinh() {
		return gioitinh;
	}
	public void setGioitinh(String gioitinh) {
		this.gioitinh = gioitinh;
	}
	public String getSdt() {
		return sdt;
	}
	public void setSdt(String sdt) {
		this.sdt = sdt;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public int getNgaysinh() {
		return ngaysinh;
	}
	public void setNgaysinh(int ngaysinh) {
		this.ngaysinh = ngaysinh;
	}
	public float getLuong() {
		return luong;
	}
	public void setLuong(float luong) {
		this.luong = luong;
	}
	public float getLuongCB() {
		return luongCB;
	}
	public void setLuongCB(float luongCB) {
		this.luongCB = luongCB;
	}
	
}
