package exam1;

public class thedog {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
//		String bread;
//		String color;
//		String size;
		System.out.println("The dog is eating");
		System.out.println("The dog is sleeping");
		
	}

}
