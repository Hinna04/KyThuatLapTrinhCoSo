package exam1;

public class dog {
	String sbread;
	String scolor;
	String ssize;
	int iage;
	void eat() {
		System.out.println("The dog is eating");
	}
	void sleep() {
		System.out.println("The dog is sleeping");
	}
	
	
	String make;
	String model;
	int year;
	void startEngine() {
		System.out.println("Engine started");
	}
	void accelerate() {
		System.out.println("Caris accelerating");
	}
	void stop() {
		System.out.println("Stop");
	}
}
