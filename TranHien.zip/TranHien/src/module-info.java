/**
 * 
 */
/**
 * @author Admin
 *
 */
module TranHien {
	requires java.desktop;
}