package BaiTapHinhHoc;

public class Circle implements Shapes {
	int R;
	public Circle() {
		super();
	}
	public Circle(int R) {
		this.R = R;
	}
	public double getChuVi() {
		return 2*R*Math.PI;
	}
	public double getDienTich() {
		return R*R*Math.PI;
	}
	public String toString() {
		return "Chu vi hình tròn là: " + this.getChuVi() + "\nDiện tích hình tròn là: " + this.getDienTich();
	}
}