package BaiTapHinhHoc;

public class Rectangle implements Shapes {
	int CD;
	int CR;
	public Rectangle(int CD, int CR) {
		this.CD = CD;
		this.CR = CR;
	}
	public Rectangle() {
		this(0, 0);
	}
	public double getChuVi() {
		return (this.CD+this.CR)*2;
	}
	public double getDienTich() {
		return this.CD*this.CR;
	}
	@Override
	public String toString() {
		return "\nChu vi hình chữ nhật: " + this.getChuVi() + "\nDiện tích hình chữ nhật: " + this.getDienTich();
	}
}
