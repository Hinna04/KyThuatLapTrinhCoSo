package BaiTapHinhHoc;

public class Square implements Shapes {
	int x;
	public Square() {
		super();
	}
	public Square(int x) {
		this.x = x;
	}
	public double getChuVi() {
		return x*4;
	}
	public double getDienTich() {
		return x*x;
	}
	public String toString() {
		return "\nChu vi hình vuông là: " + this.getChuVi() + "\nDiện tích hình vuông là: " + this.getDienTich();
	}
}