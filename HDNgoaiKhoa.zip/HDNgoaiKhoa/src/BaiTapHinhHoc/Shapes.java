package BaiTapHinhHoc;

public interface Shapes {
	public double getChuVi();
	public double getDienTich();
}
