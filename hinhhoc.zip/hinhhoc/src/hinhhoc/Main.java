package hinhhoc;

public class Main {

	public static void main(String[] args) {
//		Shapes[] shapes = new Shapes[3];
//		shapes[0] = new Circle();
//		shapes[1] = new Triangle();
//		shapes[2] = new Rectangle();
//		for(int i = 0; i < shapes.length; i++)
//			System.out.println("Dien tich la: %5.3f\n");
	}
	
}
