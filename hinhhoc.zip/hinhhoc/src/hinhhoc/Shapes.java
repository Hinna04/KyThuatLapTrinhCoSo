package hinhhoc;

public abstract class Shapes {
	public abstract double getArea();
}
