package thuchanh5;

public interface LUONG{
	float TinhLuong();
}