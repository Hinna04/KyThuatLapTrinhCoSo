package thuchanh5;
import java.util.Scanner;
/**
 * ho ten : phạm thị như quỳnh
 * lớp: 2210A06
 * 
 *
 */
public class CANBO {
	
		private String hoTen, diaChi;
		private int tuoi;
		public float hsl;
		   
		public void nhap()
		{   Scanner sc=new Scanner(System.in);
			System.out.print("nhap ho ten: ");
			hoTen=sc.nextLine();
			System.out.print("nhap dia chi: ");
			diaChi=sc.nextLine();
			System.out.print("nhap tuoi: ");
			tuoi=sc.nextInt();
			System.out.print("nhap he so luong: ");
		    hsl=sc.nextFloat();		
		}

		public void xuat()
		{
			System.out.println("Ho ten: "+hoTen);
			System.out.println("Dia chi: "+diaChi);
			System.out.println("Tuoi: "+tuoi);
			System.out.println("He so luongh: "+hsl);
			
			
		}
		}