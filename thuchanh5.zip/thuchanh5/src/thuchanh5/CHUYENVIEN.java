package thuchanh5;
import java.util.Scanner;
public class CHUYENVIEN {
	public class ChuyenVien extends CANBO implements LUONG{
		public String Phong;
		
		public float TinhLuong()
		{
			return this.hsl*1350000;
		}
		
		public void nhap()
		{
			super.nhap();
			Scanner sc=new Scanner(System.in);
			System.out.print("Nhap phong: ");
			Phong=sc.nextLine();
			
		}
		
		public void xuat()
		{
			super.xuat();
			System.out.println("Phong: "+Phong);
			System.out.println("Luong: "+TinhLuong());
		}
	}
}