package bai14;
import java.util.Scanner;
/**
 * ho tên: phạm thị như quỳnh
 * lớp: 2210A06
 * 
 *
 */
public class XE {
String tenXe;
String hangSX;
int dungtich;
float giaxe;
float thuetb;
float VAT;
String mausac;
	public XE() {
		// TODO Auto-generated constructor stub
	}
public XE  (String tenXe, String hangSX,int dungtich, float giaxe, float thuetb, float VAT, String mausac ) {
	this.tenXe=tenXe;
	this.hangSX=hangSX;
	this.dungtich=dungtich;
	this.giaxe=giaxe;
	this.thuetb=thuetb;
	this.VAT=VAT;
	this.mausac=mausac;
}
public String getTenxe() {
	return tenXe;
}
public void setTenxe(String tenXe) {
	this.tenXe=tenXe;
}
public String getHangSX() {
	return hangSX;
}
public void setHangSX( String hangSX) {
	this.hangSX=hangSX;
}
public int  getDungtich() {
	return dungtich;
}
public void setDungtich( int dungtich) {
	this.dungtich=dungtich;
}
public float getGiaxe() {
	return giaxe;
}
public void setGiaxe(float giaxe) {
	this.giaxe=giaxe;
}
public float getVAT() {
	return VAT;
}
public void setVAT(float VAT) {
	this.VAT=VAT;
}
public float getThueTB() {
	return thuetb;
}
public void setThueTB(float thuetb) {
	this.thuetb=thuetb;
}
public String getMausac() {
	return mausac;
}
public void setMausac(String mausac) {
	this.mausac=mausac;
}
public void nhap() {
	Scanner sc=new Scanner(System.in);
	System.out.println("Nhap ten xe:");
	tenXe=sc.nextLine();
	System.out.println("Nhap hang sx:");
	hangSX=sc.nextLine();
	System.out.println("Nhap dung tich:");
	dungtich=sc.nextInt();
	System.out.println("Nhap gia xe:");
	giaxe=sc.nextFloat();
	System.out.println("Nhap thue VAT:");
	VAT=sc.nextFloat();
	System.out.println("Nhap mau sac: ");
	mausac=sc.nextLine();
}
public String tiString() {
	return"Ten xe:"+tenXe+"hang sx:"+hangSX+"dung tich:"+dungtich+"thue VAT:"+VAT+"gia xe:"+giaxe+"mau sac:"+mausac+"]";
}
}
