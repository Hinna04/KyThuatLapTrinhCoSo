package bai14;
import java.util.Scanner;
public class XEMAY extends XE{
	int phanKhoi;
public XEMAY() {
	super();
}
public XEMAY(int phanKhoi) {
	super();
this.phanKhoi=phanKhoi;
}
public void nhapXM() {
	Scanner sc=new Scanner (System.in);
	super.nhap();
	System.out.println("Nhap phan khoi:");
	phanKhoi=sc.nextInt();
}
public String toString() {
	return"XEMAY[phan khoi:"+phanKhoi+super.toString();
}
}
