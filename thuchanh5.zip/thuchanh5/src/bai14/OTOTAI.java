package bai14;
import java.util.Scanner;
public class OTOTAI extends XE {
	float trongTai;

	public OTOTAI() {
		// TODO Auto-generated constructor stub
	super();
	}
	public OTOTAI(float trongTai) {
		super.nhap();
		Scanner sc= new Scanner(System.in);
		System.out.println("Nhap trong tai cua xe:");
		trongTai=sc.nextFloat();
	}
public String toString() {
	return "OTOTAI[trong tai:"+trongTai+super.toString();
}
}
