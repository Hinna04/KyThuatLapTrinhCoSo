package bai14;
import java.util.Scanner;
public class OTOKHACH extends XE {
int soCho;
	public OTOKHACH() {
		super();
	}
public OTOKHACH(int socho) {
	super();
	this.soCho=soCho;
}
public void nhapCho() {
	super.nhap();
	Scanner sc=new Scanner(System.in);
	System.out.println("Nhap so cho:");
	soCho=sc.nextInt();
}
public String toString() {
	return"OTOKHACH[so cho:"+soCho+super.toString();
}
}